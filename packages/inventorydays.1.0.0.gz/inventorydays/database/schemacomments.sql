COMMENT ON SCHEMA inventorydays
  IS 'Inventory Days of Stock Report';
